////A rework of the textures unlimited default stock mod, original can be found here; https://spacedock.info/mod/1841/Textures%20Unlimited%20Default%20Stock%20Config%20-%20Unofficial
///Mainly made for Restock, BDB & Tantares users as the stock & recolour-depot are incompatible.

//////Special thanks to Shadowmage for making it possible with the TexturesUnlimited mod; https://forum.kerbalspaceprogram.com/index.php?/topic/167450-19x-textures-unlimited-pbr-shader-texture-set-and-model-loading-api/&tab=comments#comment-3216889
///And again to Shadowmage for making sstu labs, the shiny engines inspired the mod;  https://forum.kerbalspaceprogram.com/index.php?/topic/117090-wip18x-sstulabs-low-part-count-solutions-orbiters-landers-lifters-dev-thread-11-18-18/&tab=comments#comment-2090798

//// If you play stock I reccomend Manwith Noname's Recolour depot for exterioirs found; https://forum.kerbalspaceprogram.com/index.php?/topic/174188-18x-textures-unlimited-recolour-depot/ 



////Changes:
///Edited the stock cfg to uncover the windows, unmetalled some other parts.
//Added BG compatability

///////Additions:
////Restock cfgs, BDB cfgs, TantaresSC cfgs
///Other supported mods: Apus, UniversalStorage2, Kerbanov, FTT, USI Kontainers, KIS, KAS, B9 Aero, B9HX, Heat Control, KSCFloodlight
//extras from: Knes - launchers, MOLE- engines & elec, DSEV - trusses & engines, Buffalo - chasis & metalworks, DunaDirect - Engines,Legs,habs  

//////Known issues: 
///Restock 125 fueltanks don't work, the shine shows on the VAB tiles but not on the part. I think the paint overlays are too thick for the model to shine 
//B9 Parts came out be a little bit dark 

/////Other issues:
///Why is my Lab still white?
//It's a personal preference, easily fixed by deleting the // infront of the model in the cfg, look for //model = ReStock/Assets/Command/restock-lab-1

/// Dont like a part being shiny? 
// open the corresponding cfg look for the asset path for the part then either delete the line or put // infront of model eg.  //model = Squad/blahdeblah 

/// Want to add a part;
// copy a cfg then delete the models, insert asset paths to the models or add them to the misc cfg
// model asset paths can be found in part cfgs or written manually linking to the mu file 



////Licensing 
//