

//rescaled & repuropsed stock parts for more size options

//restock & realplume cfgs in patches 