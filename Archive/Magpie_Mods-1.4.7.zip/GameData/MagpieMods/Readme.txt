////A rework of the textures unlimited default stock mod, original can be found here; https://spacedock.info/mod/1841/Textures%20Unlimited%20Default%20Stock%20Config%20-%20Unofficial

////Changes:
///Edited the original stock cfg to uncover the windows, unmetalled some parts, added updated models, added new part varients from squad updates.
//Added BG compatability
//Split configs for different shades 

///////Added configs for:
////Restock, BDB , Tantares,  Apus, UniversalStorage2, NearFuture
///FTT, USI Kontainers, KIS, KAS, B9 Aero, Heat Control, KSCFloodlight, 
///Knes, Fuji, MOLE, DSEV, Buffalos, DunaDirect, CXA, Kerbalism, TAC, Kerbanov,  k2pod
///FuelTanksPlus,  KPBS,  Quiztech, Koose,  Deepfreeze,  MunarIND,  ModPods, KipardSkylon, FlatBottomShuttleSystems

/// Want to unshine a part?
// open the corresponding cfg look for the asset path for the part then either delete the line or put // infront of the model eg.  //model = Squad/parts/partname

//// Whoah man too shiny
// Lower down the smoothness value in the cfg

///// Parts too dark 
/// Lower the metal value in the cfg 


/// Want to add a part;
// Copy a cfg then delete the models, insert paths to the models or add them to the misc cfg
// Model asset paths can sometimes be found easily in part cfgs or written manually linking to the mu file in the part folder


//////Special thanks to Shadowmage for making it possible with the TexturesUnlimited mod; https://forum.kerbalspaceprogram.com/index.php?/topic/167450-19x-textures-unlimited-pbr-shader-texture-set-and-model-loading-api/&tab=comments#comment-3216889
///And again for making sstu labs, the shiny engines inspired the mod;  https://forum.kerbalspaceprogram.com/index.php?/topic/117090-wip18x-sstulabs-low-part-count-solutions-orbiters-landers-lifters-dev-thread-11-18-18/&tab=comments#comment-2090798

//// If you play stock I reccomend Manwith Noname's Recolour depot for exterioirs found; https://forum.kerbalspaceprogram.com/index.php?/topic/174188-18x-textures-unlimited-recolour-depot/ 


////Licensing 
//Wasnt sure which to put so I used the same as TU as it uses the TU shaders 